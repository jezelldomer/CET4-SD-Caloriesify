Group Name: DnD Enterprise

Members: Daza, Ronnie M. and Domer, Jezell C.

Project Name: Dietar

Project Description:
Dietar is a mobile application designed to help users maintain a healthy lifestyle by tracking their diet and exercise plans. The app uses the user's BMI to generate personalized exercise and diet plans, and includes a journal feature where users can take notes on their daily activities, food intake, and progress.


Github link: https://github.com/jezelldomer/CET4-Dietar

Trello link: https://trello.com/invite/b/UPojIKq6/ATTI994a847db3373b3a6ea23a3d0d65547eCE0C4B52/dnd-enterprise-dietar